# Instructions

Practice using div and span tags as well as id and class attributes. 

Go to the index.html file inside the 2_exercise_html folder and follow the instructions in the index.html file. You'll notice that as you type html into that file, the results appear on the right-hand side of the screen.

You'll see in the index.html file that html comments have the following syntax:

<!-- This is an html comment -->

When you're finished, there's a solution file in example_answer.html. Compare your code to the solution file.